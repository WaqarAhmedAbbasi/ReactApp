﻿

   --------------------------------------------------------------------------------
                     README file for AdvancedStringBuilder v0.1.1

   --------------------------------------------------------------------------------

           Copyright (c) 2018-2024 Andrey Taritsyn - http://www.taritsyn.ru


   ===========
   DESCRIPTION
   ===========
   Contains a simple implementation of the pool and extension methods for string
   builder.

   =============
   RELEASE NOTES
   =============
   Enabled a SourceLink in NuGet package.

   ============
   PROJECT SITE
   ============
   https://github.com/Taritsyn/AdvancedStringBuilder