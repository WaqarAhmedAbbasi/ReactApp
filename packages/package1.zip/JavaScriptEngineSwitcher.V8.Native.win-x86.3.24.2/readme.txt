﻿

   --------------------------------------------------------------------------------
            README file for JS Engine Switcher: V8 for Windows x86 v3.24.2

   --------------------------------------------------------------------------------

           Copyright (c) 2013-2024 Andrey Taritsyn - http://www.taritsyn.ru


   ===========
   DESCRIPTION
   ===========
   This package is deprecated. Instead, it is recommended to use a
   Microsoft.ClearScript.V8.Native.win-x86 package.

   =============
   RELEASE NOTES
   =============
   Microsoft ClearScript.V8 was updated to version 7.4.5 (support of the V8
   version 12.3.219.12).

   =============
   DOCUMENTATION
   =============
   See documentation on GitHub -
   http://github.com/Taritsyn/JavaScriptEngineSwitcher